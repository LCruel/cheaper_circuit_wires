data.raw["recipe"]["red-wire"].result_count = 10 
data.raw["recipe"]["green-wire"].result_count = 10